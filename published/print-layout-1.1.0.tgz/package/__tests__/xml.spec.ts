import { printLayout, sanitizeDetoxNodes, xmlToLayout } from "../src/index";

describe.skip("xmlToLayout", () => {
  it("should transform simple xml to layout", () => {
    const layout = printLayout(xmlToLayout("<root><child>text</child></root>"));
    expect("\n" + layout).toEqual(`
root ▶ child ("text")`);
  });

  it("should transform xml with id and label attributes to layout", () => {
    const xml = `<ViewHierarchy>
 <UIWindow alpha="1.0" class="UIWindow" focused="false" height="896" id="detox_temp_" visibility="visible" width="414">
  <RCTParagraphComponentView alpha="1.0" class="RCTParagraphComponentView" focused="false" height="24" id="wix.woa.memberships.E2E_APP.LOAD_STORYBOOK.title" label="Glimpse" tag="16" visibility="visible" width="62" x="0" y="15">
   <RCTParagraphTextView alpha="1.0" class="RCTParagraphTextView" focused="false" height="24" id="detox_temp_0_0_0_0_0_0_1_0_0_0_0_0_0_1_0_0_0_0_0_0_0" visibility="visible" width="62" x="0" y="0" />
  </RCTParagraphComponentView>
 </UIWindow>
</ViewHierarchy>`;
    const node = xmlToLayout(xml);

    expect(node).toEqual({
      type: "ViewHierarchy",
      children: [
        {
          type: "UIWindow",
          tag: "[detox_temp_]",
          children: [
            {
              type: "RCTParagraphComponentView",
              tag: "[wix.woa.memberships.E2E_APP.LOAD_STORYBOOK.title]",
              content: ["Glimpse"],
              children: [
                {
                  type: "RCTParagraphTextView",
                  tag: "[detox_temp_0_0_0_0_0_0_1_0_0_0_0_0_0_1_0_0_0_0_0_0_0]",
                },
              ],
            },
          ],
        },
      ],
    });

    expect("\n" + printLayout(sanitizeDetoxNodes(node))).toEqual(`
ViewHierarchy ▶ UIWindow ▶ RCTParagraphComponentView [wix.woa.memberships.E2E_APP.LOAD_STORYBOOK.title] ("Glimpse")
  RCTParagraphTextView`);
  });

  it("should transform xml with nested elements to layout", () => {
    const xml = `<ViewHierarchy>
    <UITabBar alpha="1.0" class="UITabBar" focused="false" height="83" id="detox_temp_0_0_0_1" label="Tab Bar" visibility="visible" width="414" x="0" y="813">
      <_UIBarBackground alpha="1.0" class="_UIBarBackground" focused="false" height="83" id="detox_temp_0_0_0_1_0" visibility="visible" width="414" x="0" y="0">
       <UIImageView alpha="1.0" class="UIImageView" focused="false" height="83" id="detox_temp_0_0_0_1_0_0" visibility="visible" width="414" x="0" y="0" />
       <UIImageView alpha="1.0" class="UIImageView" focused="false" height="83" id="detox_temp_0_0_0_1_0_1" visibility="visible" width="414" x="0" y="0" />
       <_UIBarBackgroundShadowView alpha="1.0" class="_UIBarBackgroundShadowView" focused="false" height="1" id="detox_temp_0_0_0_1_0_2" visibility="visible" width="414" x="0" y="-1">
        <_UIBarBackgroundShadowContentImageView alpha="1.0" class="_UIBarBackgroundShadowContentImageView" focused="false" height="1" id="detox_temp_0_0_0_1_0_2_0" visibility="visible" width="414" x="0" y="0" />
       </_UIBarBackgroundShadowView>
       <_UIBarBackgroundShadowView alpha="1.0" class="_UIBarBackgroundShadowView" focused="false" height="0" id="detox_temp_0_0_0_1_0_3" visibility="visible" width="414" x="0" y="0">
        <_UIBarBackgroundShadowContentImageView alpha="1.0" class="_UIBarBackgroundShadowContentImageView" focused="false" height="0" id="detox_temp_0_0_0_1_0_3_0" visibility="visible" width="414" x="0" y="0" />
       </_UIBarBackgroundShadowView>
      </_UIBarBackground>
      <UITabBarButton alpha="1.0" class="UITabBarButton" focused="false" height="48" id="wix.demo.E2E_TAB" label="E2E" visibility="visible" width="203" x="2" y="1">
       <UITabBarSwappableImageView alpha="1.0" class="UITabBarSwappableImageView" focused="false" height="24" id="detox_temp_0_0_0_1_1_0" visibility="visible" width="24" x="89" y="5" />
       <UITabBarButtonLabel alpha="1.0" class="UITabBarButtonLabel" focused="false" height="13" id="detox_temp_0_0_0_1_1_1" label="E2E" text="E2E" visibility="visible" width="18" x="92" y="34" />
      </UITabBarButton>
      <UITabBarButton alpha="1.0" class="UITabBarButton" focused="false" height="48" id="wix.demo.BOTTOM_TAB_STORYBOOK" label="Storybook" visibility="visible" width="203" x="209" y="1">
       <UITabBarSwappableImageView alpha="1.0" class="UITabBarSwappableImageView" focused="false" height="24" id="detox_temp_0_0_0_1_2_0" visibility="visible" width="24" x="89" y="5" />
       <UITabBarButtonLabel alpha="1.0" class="UITabBarButtonLabel" focused="false" height="13" id="detox_temp_0_0_0_1_2_1" label="Storybook" text="Storybook" visibility="visible" width="50" x="76" y="34" />
      </UITabBarButton>
     </UITabBar>
</ViewHierarchy>`;
    const node = xmlToLayout(xml);
    const layout = printLayout(sanitizeDetoxNodes(node));
    expect("\n" + layout).toEqual(`
ViewHierarchy ▶ UITabBar ("Tab Bar")
  _UIBarBackground
    UIImageView
    UIImageView
    _UIBarBackgroundShadowView ▶ _UIBarBackgroundShadowContentImageView
    _UIBarBackgroundShadowView ▶ _UIBarBackgroundShadowContentImageView
  UITabBarButton [wix.demo.E2E_TAB]
    UITabBarSwappableImageView
    UITabBarButtonLabel ("E2E")
  UITabBarButton [wix.demo.BOTTOM_TAB_STORYBOOK]
    UITabBarSwappableImageView
    UITabBarButtonLabel ("Storybook")`);
  });
});
